
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class ControllerDataBuku {

    ModelDataBuku modeldatabuku;
    ViewDataBuku viewdatabuku;
    

    public ControllerDataBuku(ModelDataBuku modeldatabuku, ViewDataBuku viewdatabuku) {
        this.modeldatabuku = modeldatabuku;
        this.viewdatabuku = viewdatabuku;

        if (modeldatabuku.getBanyakData() != 0) {
            String dataBuku[][] = modeldatabuku.readBuku();
            viewdatabuku.tabel.setModel((new JTable(dataBuku, viewdatabuku.namaKolom)).getModel());
            listenerTabel();
        } else {
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }

        viewdatabuku.btnTambahPanel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nim = viewdatabuku.getJudulB();
                String nama = viewdatabuku.getKategori();
                String alamat = viewdatabuku.getPenerbit();
                String jk = viewdatabuku.getISBN();
                String suplier = viewdatabuku.getSuplier();
                String tahun = viewdatabuku.getTahun();
                String harga = viewdatabuku.getHarga();
                String stok = viewdatabuku.getStok();

                modeldatabuku.insertBuku(judul, kategori, penerbit, isbn, suplier, tahun, harga, stok);

                String dataBuku[][] = modeldatabuku.readBuku();
                viewdatabuku.tabel.setModel(new JTable(dataBuku, viewdatabuku.namaKolom).getModel());
                listenerTabel();
            }
        });
        
        viewdatabuku.btnUbahPanel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nim = viewdatabuku.getJudulB();
                String nama = viewdatabuku.getKategori();
                String alamat = viewdatabuku.getPenerbit();
                String jk = viewdatabuku.getISBN();
                String suplier = viewdatabuku.getSuplier();
                String tahun = viewdatabuku.getTahun();
                String harga = viewdatabuku.getHarga();
                String stok = viewdatabuku.getStok();

                modeldatabuku.updateBuku(judul, kategori, penerbit, isbn, suplier, tahun, harga, stok);
                
                String dataBuku[][] = modeldatabuku.readBuku();
                viewdatabuku.tabel.setModel(new JTable(dataBuku, viewdatabuku.namaKolom).getModel());
                listenerTabel();
            }
        });
        
        viewdatabuku.btnHapusPanel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nim = viewdatabuku.getJudulB();
                String nama = viewdatabuku.getKategori();
                String alamat = viewdatabuku.getPenerbit();
                String jk = viewdatabuku.getISBN();
                String suplier = viewdatabuku.getSuplier();
                String tahun = viewdatabuku.getTahun();
                String harga = viewdatabuku.getHarga();
                String stok = viewdatabuku.getStok();

                modeldatabuku.deleteBuku(isbn);
                
                String dataBuku[][] = modeldatabuku.readBuku();
                viewdatabuku.tabel.setModel(new JTable(dataBuku, viewdatabuku.namaKolom).getModel());
                resetForm();
                listenerTabel();
            }
        });
        
        viewdatabuku.btnBatalPanel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetForm();
                
                String dataBuku[][] = modeldatabuku.readBuku();
                viewdatabuku.tabel.setModel(new JTable(dataBuku, viewdatabuku.namaKolom).getModel());
                listenerTabel();
            }
        });
    }

    ControllerDataBuku(ViewDataBuku viewdatabuku, ModelDataBuku modeldatabuku) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void listenerTabel() {
        String data[][] = modelDataBuku.readMahasiswa();
        String dataBuku[][] = modelDataBuku.readBuku();
        viewdatabuku.tabel.setModel(new JTable(dataBuku, viewdatabuku.namaKolom).getModel());
        viewdatabuku.tabel.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                super.mousePressed(e);
                int row = viewdatabuku.tabel.getSelectedRow();
                int col = viewdatabuku.tabel.getSelectedColumn();

                viewdatabuku.tfnim.setText(data[row][0].toString());
                viewdatabuku.tfnim.setEnabled(false);
                viewdatabuku.tfNamaMhs.setText(data[row][1].toString());
                if (data[row][2].toString().equals("Perempuan")) {
                    viewdatabuku.rbWanita.setSelected(true);
                    viewdatabuku.rbPria.setSelected(false);
                } else if (data[row][2].toString().equals("Laki-laki")) {
                    viewdatabuku.rbPria.setSelected(true);
                    viewdatabuku.rbWanita.setSelected(false);
                }
                viewdatabuku.tfAlamatMhs.setText(data[row][3].toString());
                viewdatabuku.cmbAgama.setSelectedItem(data[row][4]);
            }
        });
    }
    
    public void resetForm(){
        viewdatabuku.tfnim.setText("");
        viewdatabuku.tfnim.setEnabled(true);
        viewdatabuku.tfNamaMhs.setText("");
        viewdatabuku.rbPria.setSelected(false);
        viewdatabuku.rbWanita.setSelected(false);
        viewdatabuku.tfAlamatMhs.setText("");
        viewdatabuku.cmbAgama.setSelectedItem("--Pilih--");
    }

}

}
