public class MVC_DataBuku {
    ViewDataBuku viewdatabuku = new ViewDataBuku();
    ModelDataBuku modeldatabuku = new ModelDataBuku();
    ControllerDataBuku controllerdatabuku = new ControllerDataBuku(viewdatabuku, modeldatabuku)
}
